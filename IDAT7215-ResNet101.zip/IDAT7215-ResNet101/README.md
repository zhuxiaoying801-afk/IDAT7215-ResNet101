# ResNet101 Reproduction: Defect Detection in 3D-Printed Objects

Transfer-learning reproduction of **ResNet101** from the paper:

> M. M. Ahsan, S. Raman, Y. Liu, Z. Siddique,
> *"Defect analysis of 3D printed object using transfer learning approaches,"*
> Expert Systems with Applications, vol. 253, p. 124293, 2024.
> https://doi.org/10.1016/j.eswa.2024.124293

- Dataset: https://github.com/mahsan2/AMdataset
- Paper authors' code: https://github.com/mahsan2/AM3d
- Style reference (coursemate's reproduction): https://github.com/AHJ8273528/IDAT7215-EfficientNetB0

## Method

Following the paper's flow diagram, an ImageNet-pretrained **ResNet101** is used as a
frozen feature extractor and only a small new classification head is trained:

```
Input (224x224x3)
  -> ResNet101 (ImageNet weights, FROZEN)
  -> GlobalAveragePooling2D
  -> BatchNormalization
  -> Dropout(0.3)
  -> Dense(256, relu)          # updated layer
  -> Dropout(0.3)
  -> Dense(1, sigmoid)         # FC output, P(Non-Defect)
```

Class labels: `badcylinder = 0 (Defect)`, `goodcylinder = 1 (Non-Defect)`,
assigned alphabetically from the folder names. The sigmoid output is therefore
**P(Non-Defect)**; an image is classified as *Defect* when this probability is >= 0.5.

## Environment

- Python 3.14 (any 3.10+ works)
- TensorFlow 2.x with Keras 3
- numpy, pandas, scikit-learn, matplotlib, Pillow

```bash
pip install tensorflow numpy pandas scikit-learn matplotlib pillow
```

## Data preparation

Download the dataset and arrange it as follows (this matches the repository layout):

```
AMdataset-main/
  dataset/            # Study One: 136 defect + 135 non-defect (small, balanced)
    badcylinder/
    goodcylinder/
  Augmented_data/     # Study Two: 947 defect + 2070 non-defect (large, imbalanced)
    Badaug/
    Goodaug/
```

Update `DATA_ROOT` in **Step 2** of the notebook to point to your local
`AMdataset-main` folder.

## Usage

Open `resnet101_3defect_detection.ipynb` and run all cells in order
(**Kernel -> Restart Kernel & Run All Cells** is recommended for reproducibility).

- To switch between experiments, set `STUDY = "one"`, `"two"` or `"three"` in
  **Step 2**, then restart and run all cells again.
- Results of each study are written to a separate `results_study_one/` /
  `results_study_two/` / `results_study_three/` directory, so runs never
  overwrite each other.

### Notebook pipeline

| Step | Content |
|---|---|
| 1 | Import libraries |
| 2 | Paths and hyperparameters |
| 3 | Count images per class (data sanity check) |
| 4 | Data split (70% train / 15% val / 15% test) and pipelines — stratified random for Studies One/Two, time-ordered for Study Three; split manifests saved |
| 5 | Visualize training samples |
| 6 | Build frozen ResNet101 + classification head |
| 7 | Training (EarlyStopping, LR reduction, best-model checkpoint) |
| 8 | Training curves |
| 9 | Test-set evaluation: Accuracy / Precision / Recall / F1 / MCC / Kappa / AUC, confusion matrix, ROC curve |
| 10 | Per-image predictions CSV (auditable evidence) |
| 11 | Metrics summary CSV |

## Hyperparameters

| Parameter | Value | Note |
|---|---|---|
| Input size | 224 x 224 x 3 | ResNet standard input |
| Optimizer | Adam | Paper ablation: Adam / RMSprop clearly outperform SGD |
| Learning rate | 1e-4 | Reduced from 1e-3 after a trial run showed mild overfitting (val_loss rebound) |
| Epochs | 15 | Paper reports convergence after ~20 epochs; 15 is sufficient at lr=1e-4 |
| Batch size | 30 | Matches the reference reproduction |
| Seed | 42 | All randomness (split, shuffling, init) is fixed |

## Reproduction notes and deviations from the paper

1. **Data split**: the paper does not publish its exact split. We use a
   **stratified random 70/15/15 split per class** with a fixed seed
   (Study One: 189 / 40 / 42; Study Two: 2111 / 452 / 454). Stratification guarantees
   both classes appear in every subset — a plain `shuffle=False` slice of the sorted
   file list would put a single class into the test set.
2. **Hyperparameters**: epochs and learning rate were tuned based on a pilot run
   (val_loss began rising after ~10 epochs at lr=1e-3); the paper fixes neither value.
3. **Expected outcome**: on Study One the model typically reaches 100% test accuracy
   within a few epochs. This is higher than the paper's reported ~0.85 for ResNet101,
   attributable to the different (smaller) test split and the tuned learning rate.
4. Training is performed on CPU-friendly settings; no GPU is required for Study One.

## Outputs (per study)

| File | Description |
|---|---|
| `resnet101_best.keras` / `resnet101_final.keras` | Trained models |
| `metrics.csv` | Full metric summary of the run |
| `per_image_predictions.csv` | Per-image ground truth and prediction (auditable) |
| `accuracy.png` / `loss.png` | Training curves |
| `confusion_matrix.png` | Confusion matrix |
| `roc_curve.png` | ROC curve with AUC |
| `per_image_predictions_preview.png` | Preview of the per-image evidence |

## Results

Three experiments, all with Adam, lr = 1e-4, 15 epochs:

- **Study One** (small, balanced: 136 defect + 135 non-defect): stratified
  random 70/15/15 split, test = 42 images.
- **Study Two** (large, imbalanced: 947 defect + 2070 non-defect): stratified
  random 70/15/15 split on the augmented dataset, test = 454 images.
- **Study Three** (temporal extrapolation): same raw photos as Study One, but
  split by capture time (filename order) — first 70% train, last 15% test —
  to expose near-duplicate leakage of random splits.

| Metric | Study One (42 test) | Study Two (454 test) | Study Three (42 test) | Paper ResNet101 (Study One) |
|---|---|---|---|---|
| Accuracy | **1.000** | **1.000** | **1.000** | 0.850 |
| Precision | **1.000** | **1.000** | **1.000** | - |
| Recall | **1.000** | **1.000** | **1.000** | - |
| F1-score | **1.000** | **1.000** | **1.000** | 0.850 |
| MCC | **1.000** | **1.000** | **1.000** | - |
| Kappa | **1.000** | **1.000** | **1.000** | - |
| AUC | **1.000** | **1.000** | **1.000** | - |

Confusion matrices (rows = true, columns = predicted):

![Study One Confusion Matrix](results_study_one/confusion_matrix.png)
![Study Two Confusion Matrix](results_study_two/confusion_matrix.png)

ROC curves (all AUC = 1.000):

![Study One ROC](results_study_one/roc_curve.png)
![Study Two ROC](results_study_two/roc_curve.png)

Training curves and per-image prediction evidence (`per_image_predictions.csv`)
are stored in each `results_study_*/` folder; previews:

![Study Two Accuracy](results_study_two/accuracy.png)
![Study Two Loss](results_study_two/loss.png)
![Study One Predictions](results_study_one/per_image_predictions_preview.png)
![Study Two Predictions](results_study_two/per_image_predictions_preview.png)

### Discussion

**Perfect scores are real — and they are the finding.** ResNet101 classifies
every test image correctly in all three experiments (Study Two: TP = 143,
FP = 0, FN = 0, TN = 311). This exceeds the paper's ResNet101 (0.85 in Study
One; weaker than VGG16 / MobileNetV2 in Study Two with FP = 72, FN = 12), and
matches the paper's own ceiling — VGG16, MobileNetV2, InceptionResNetV2 and
NASNetLarge also reach near-perfect scores. The paper's low ResNet101 numbers
reflect its training configuration rather than the task's difficulty; with a
tuned learning rate the task is fully solved.

**Why Study Three matters: the 1.000 is not evidence of generalization.**
Even under a temporal split — training on early photos, testing on photos taken
later — the model stays perfect. The reason is the data itself: the dataset
consists of time-lapse frames of the *same* printed cylinders, captured every
few seconds. Consecutive frames are near-duplicates, and a defect, once it
appears, persists until the end of the print. Random splits (Studies One/Two)
leak near-identical frames into the test set; even the time-ordered split
(Study Three) cannot separate frames of the same object. Consequently, **no
split of this dataset can measure generalization to independent print runs** —
there are no independent print sessions in the data. This is a limitation of
the dataset, not of the model, and it means accuracy on these benchmarks
should be read as "performance on this printing session", not "performance on
new printing scenarios".

Practical takeaways:

1. **Tuned optimization matters**: the pilot run at lr = 1e-3 showed a val_loss
   rebound (overfitting); lr = 1e-4 removed it — validation loss decreases
   monotonically in all three runs.
2. **Split protocol must match the deployment scenario**: for production
   defect detection, data collection should record independent print sessions so
   that session-level splits become possible.
3. **Classification != localization**, as the paper also notes via LIME: a
   perfect image-level score does not imply the model can point to where the
   defect is. Our model performs image-level classification only.

## Repository structure

```
IDAT7215-ResNet101/
  resnet101_3defect_detection.ipynb   # the full reproduction notebook
  README.md
  .gitignore
  results_study_one/                  # Study One results
    confusion_matrix.png  roc_curve.png
    accuracy.png  loss.png
    metrics.csv  per_image_predictions_preview.png
  results_study_two/                  # Study Two results
    (same file names as above)
  results_study_three/                # Study Three (temporal split) results
    (same file names as above)
```

Each `results_study_*/` folder also contains `per_image_predictions.csv` and
`split_train/val/test.csv` (the exact split manifests) generated by the notebook.

The dataset images are **not** redistributed here; download them from
https://github.com/mahsan2/AMdataset. Trained model files (`.keras`, >100 MB)
are also excluded from the repository; they can be shared via a release archive
if required.

## Citation

```bibtex
@article{ahsan2024defect,
  title={Defect analysis of 3D printed object using transfer learning approaches},
  author={Ahsan, Md Manjurul and Raman, Shivakumar and Liu, Yingtao and Siddique, Zahed},
  journal={Expert Systems with Applications},
  volume={253},
  pages={124293},
  year={2024},
  publisher={Elsevier}
}
```
